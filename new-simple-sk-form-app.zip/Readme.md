import SkForm from 'new-simple-sk-form-app';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <SkForm/>
      </header>
    </div>
  );
}

export default App;