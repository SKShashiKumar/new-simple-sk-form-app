import React from "react";
import { PageContext } from "../context/PageContext";

const ForgotPassword = () => {
    const { setPageNo } = React.useContext(PageContext);
    const getEmail = React.useRef(false)

    const getForgotForm = (e) => {
        e.preventDefault()
        setPageNo(1)
    }

    return (
        <div className="container">
            <form className="forgot-form mt-3" onSubmit={getForgotForm}>
                <div className="row justify-content-center align-items-center mb-4">
                    <div className="col-12 text-center">
                        <h1>Forgot Password</h1>
                    </div>
                </div>
                <div className="row justify-content-center align-items-center mb-3">
                    <div className="col-6">
                        <span className="text-start">Email : </span>
                        <input type="email" className="form-control" ref={getEmail} required/>
                    </div>
                </div>
                <div className="row justify-content-center align-items-center mb-3">
                    <div className="col-6 text-center">
                        <button className="btn btn-info w-25" type="submit">
                            Send Link
                        </button>
                    </div>
                </div>
            </form>
            <div className="row justify-content-center align-items-center mb-4 text-center">
                <span className="col-2" onClick={() => setPageNo(1)} role="button">Login</span>
                <span className="col-2" onClick={() => setPageNo(2)} role="button">signup</span>
            </div>
        </div>
    );
};

export default ForgotPassword;
