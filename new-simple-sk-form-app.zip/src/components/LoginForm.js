import React from "react";
import { PageContext } from "../context/PageContext";

const LoginForm = () => {
  const [GetDatas, setGetDatas] = React.useState(false);
  const { setPageNo } = React.useContext(PageContext);

  const getName = React.useRef(false);
  const getPassword = React.useRef(false);

  const getLoginForm = (e) => {
    e.preventDefault();
    // console.log(`Name : ${getName.current.value},  Password : ${getPassword.current.value}`)
    setGetDatas({
      Name: getName.current.value,
      Password: getPassword.current.value,
    });

    setPageNo(4)
  };

  return (
    <div className="login-form container">
    <form className="mt-3" onSubmit={getLoginForm}>
      <div className="row justify-content-center align-items-center mb-4">
        <div className="col-12 text-center">
          <h1>Login</h1>
        </div>
      </div>
      <div className="row justify-content-center align-items-center mb-4">
        <div className="col-6">
          <span className="text-start">Name : </span>
          <input type="text" className="form-control" ref={getName} required/>
        </div>
      </div>
      <div className="row justify-content-center align-items-center mb-4">
        <div className="col-6">
          <span className="text-start">Password : </span>
          <input type="text" className="form-control" ref={getPassword} required/>
        </div>
      </div>
      <div className="row justify-content-center align-items-center mb-4">
        <div className="col-6 text-center">
          <button className="btn btn-success w-25" type="submit">
            Login
          </button>
        </div>
      </div>
    </form>
    <div className="row justify-content-center align-items-center mb-4 text-center">
    <span className="col-2" onClick={() => setPageNo(2)} role="button">SignUp</span>
    <span className="col-2" onClick={() => setPageNo(3)} role="button">Forgot Password</span>
    </div>
    </div>
  );
};

export default LoginForm;
