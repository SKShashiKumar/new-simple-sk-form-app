import React from "react";
import { PageContext } from "../context/PageContext";

const Welcome = () => {

    const {setPageNo} = React.useContext(PageContext)
  return (
    <div className="Welcome">
      <div className="container mt-4">
        <div className="row justify-content-center text-center">
          <div className="col-6 mb-2">
            <h1>Welcome</h1>
          </div>
          <div className="col-12">
            <button className="btn btn-danger" onClick={() => setPageNo(1)}>Logout</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
