import React from "react";
import ForgotPassword from "./components/ForgotPassword";
import LoginForm from "./components/LoginForm";
import SignUpForm from "./components/SignUpForm";
import Welcome from "./components/Welcome";
import { PageContext } from "./context/PageContext";
import "bootstrap/dist/css/bootstrap.min.css"; 


const SkForm = () => {
  const [PageNo, setPageNo] = React.useState(1);

  return (
    <>
      <PageContext.Provider value={{ PageNo, setPageNo }}>
        {PageNo === 1 && <LoginForm />}
        {PageNo === 2 && <SignUpForm />}
        {PageNo === 3 && <ForgotPassword />}
        {PageNo === 4 && <Welcome/>}
      </PageContext.Provider>
    </>
  );
};

export default SkForm;
